Valerie: Client
Valerie's Files: Chat, ChatClient, ChatFrame, ChatServer, LoginPanel
		   ManagerPanel, SettingsPanel, DuberChatLogo.png

Kenny: Server